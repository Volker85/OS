#ifndef PROJECT_DEFINES_H_INCLUDED
#define PROJECT_DEFINES_H_INCLUDED

#define GPIOA_CLEAR GPIOA->BSRRH
#define GPIOA_SET   GPIOA->BSRRL

#define GPIOB_CLEAR GPIOB->BSRRH
#define GPIOB_SET   GPIOB->BSRRL

#define GPIOC_CLEAR GPIOC->BSRRH
#define GPIOC_SET   GPIOC->BSRRL

#define GPIOD_CLEAR GPIOD->BSRRH
#define GPIOD_SET   GPIOD->BSRRL

#define GPIOE_CLEAR GPIOE->BSRRH
#define GPIOE_SET   GPIOE->BSRRL

#define LED_GREEN   GPIO_Pin_12
#define LED_ORANGE  GPIO_Pin_13
#define LED_RED     GPIO_Pin_14
#define LED_BLUE    GPIO_Pin_15

void Delay(__IO uint32_t nCount);


/*GPIO Defines for STM32F4***********/

//For Read: GPIOx_IDR bits 15..0 -> Pin 15..0
//For Direct output: GPIOx_ODR bits 15..0 -> Pin 15..0


//defines for GPIO-Mode
#define GPIO_MODE_INPUT     0x00
#define GPIO_MODE_OUTPUT    0x01
#define GPIO_MODE_AF        0x02
#define GPIO_MODE_ANALOG    0x03
//fpr shift
#define GPIO_MODE_PIN0      0
#define GPIO_MODE_PIN1      2
#define GPIO_MODE_PIN2      4
#define GPIO_MODE_PIN3      6
#define GPIO_MODE_PIN4      8
#define GPIO_MODE_PIN5      10
#define GPIO_MODE_PIN6      12
#define GPIO_MODE_PIN7      14
#define GPIO_MODE_PIN8      16
#define GPIO_MODE_PIN9      18
#define GPIO_MODE_PIN10     20
#define GPIO_MODE_PIN11     22
#define GPIO_MODE_PIN12     24
#define GPIO_MODE_PIN13     26
#define GPIO_MODE_PIN14     28
#define GPIO_MODE_PIN15     30

//defines for GPIO-Type
#define GPIO_TYPE_PUSHPULL  0
#define GPIO_TYPE_OPENDRAIN 1
//for Shift
#define GPIO_TYPE_PIN0      0
#define GPIO_TYPE_PIN1      1
#define GPIO_TYPE_PIN2      2
#define GPIO_TYPE_PIN3      3
#define GPIO_TYPE_PIN4      4
#define GPIO_TYPE_PIN5      5
#define GPIO_TYPE_PIN6      6
#define GPIO_TYPE_PIN7      7
#define GPIO_TYPE_PIN8      8
#define GPIO_TYPE_PIN9      9
#define GPIO_TYPE_PIN10     10
#define GPIO_TYPE_PIN11     11
#define GPIO_TYPE_PIN12     12
#define GPIO_TYPE_PIN13     13
#define GPIO_TYPE_PIN14     14
#define GPIO_TYPE_PIN15     15

//defines for GPIO-Speed
#define GPIO_SPEED_2MHZ     0
#define GPIO_SPEED_25MHZ    1
#define GPIO_SPEED_50MHZ    2
#define GPIO_SPEED_100MHZ   3
//for shift
#define GPIO_SPEED_PIN0      0
#define GPIO_SPEED_PIN1      2
#define GPIO_SPEED_PIN2      4
#define GPIO_SPEED_PIN3      6
#define GPIO_SPEED_PIN4      8
#define GPIO_SPEED_PIN5      10
#define GPIO_SPEED_PIN6      12
#define GPIO_SPEED_PIN7      14
#define GPIO_SPEED_PIN8      16
#define GPIO_SPEED_PIN9      18
#define GPIO_SPEED_PIN10     20
#define GPIO_SPEED_PIN11     22
#define GPIO_SPEED_PIN12     24
#define GPIO_SPEED_PIN13     26
#define GPIO_SPEED_PIN14     28
#define GPIO_SPEED_PIN15     30

//defines for GPIO-PULLUP/Down
#define GPIO_PUPD_NOP       0
#define GPIO_PUPD_PU        1
#define GPIO_PUPD_PD        2
#define GPIO_PUPD_RESERVED  3
//for shift
#define GPIO_PUPD_PIN0      0
#define GPIO_PUPD_PIN1      2
#define GPIO_PUPD_PIN2      4
#define GPIO_PUPD_PIN3      6
#define GPIO_PUPD_PIN4      8
#define GPIO_PUPD_PIN5      10
#define GPIO_PUPD_PIN6      12
#define GPIO_PUPD_PIN7      14
#define GPIO_PUPD_PIN8      16
#define GPIO_PUPD_PIN9      18
#define GPIO_PUPD_PIN10     20
#define GPIO_PUPD_PIN11     22
#define GPIO_PUPD_PIN12     24
#define GPIO_PUPD_PIN13     26
#define GPIO_PUPD_PIN14     28
#define GPIO_PUPD_PIN15     30


#endif // PROJECT_DEFINES_H_INCLUDED
