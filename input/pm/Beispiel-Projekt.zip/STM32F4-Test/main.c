#include "stm32f4xx.h"
#include "stm32f4xx_conf.h"
#include "project_defines.h"

int main(void) {

    //Clock für GPIOD (LEDs, Taster) aktivieren
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

    //GPIOD (LEDS) konfigurieren
    GPIO_InitTypeDef  GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin   = LED_GREEN | LED_ORANGE | LED_RED | LED_BLUE;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    //Led an

    GPIOD->BSRRL = LED_ORANGE;// | LED_BLUE;
    Delay(10000000L);
    GPIOD->BSRRL = LED_RED;// | LED_BLUE;
    Delay(10000000L);
    GPIOD->BSRRL = LED_BLUE;
    Delay(10000000L);
    GPIOD->BSRRL = LED_GREEN;// | LED_BLUE;
    Delay(10000000L);
    //Led aus
    //GPIOD->BSRRH = LED_GREEN | LED_ORANGE | LED_RED | LED_BLUE;

    while (1) {

    }
}

void Delay(__IO uint32_t nCount) {
  while(nCount--) {
  }
}
